## Specify the path where you downloaded the folder with all R files
path<-"/Users/tstadler/Documents/Data/Uni/Research/R/LineageTrees/paper/"

###############################################################
# The fates are labelled as following: A (Apoptosis-death). D (Division), N (Non-dividing), L (lost)
# 
# DATASTRUCTURE when a tree set is read in:
# readset()
# [[1]]: all D-cell lifetimes
# [[2]]: all A-cell lifetimes
# [[3]]: all N-cell lifetimes (lifetimes ignored in MLpar since non-dividers)
# [[4]]: all L-cell lifetimes (lifetimes ignored in MLpar since lost)
# [[5]]:
# each entry one tree:
# row 1: 5, number leaves (max 8 if all divider cells)
# next rows: cell type, branch length
#
###############################################################
# ANALYSIS
# Training is Set1
# Test is Set2
# if one type does not occur, then its probability to occur is set to 10^(-5) (instead of 0 - otherwise there are likelihood problems!)
###############################################################

library(ape)
library(xtable)
setwd(path)
source("TreeStats-Functions.R") # contains all required functions
ignoreL<-1 # Here we specify that lost is not a special type, but we simply do not know if D, A, N.

###############################################################
## Read Datasets.
mins <- 1  # minimum number of tips. 3 means that at least 2 divisions I.e. at least 3 generations.
bootstrapN <- 100 # number of datasets regenerated; put to smaller than 100 when testing.
#
pathEarly<-paste(path,"Data/earlyMPPs",sep="")
pathLate<-paste(path,"Data/lateMPPs",sep="")
pathHSC<-paste(path,"Data/HSCs",sep="")
treedataEarly <-readset(c(pathEarly),minsize=mins,maxsize=4,shift=1)
treedataLate <-readset(c(pathLate),minsize=mins,maxsize=4,shift=1)
treedataHSC <-readset(c(pathHSC),minsize=mins,maxsize=4,shift=1)

## Plot simple stats for datasets, namely time to division, apoptosis.
## Future work: use distribution closer to the empirical one rather than normal distribution.
pathOut<-paste(path,"Results",sep="")
setwd(pathOut)
breaks<-50
pdf(file="WaitingTimes.pdf")
hist(treedataHSC[[1]],xlab="Time to division",ylab="Frequency",main="HSC",breaks=breaks)
hist(treedataHSC[[2]],xlab="Time to apoptosis",ylab="Frequency",main="HSC",breaks=breaks)
hist(treedataEarly[[1]],xlab="Time to division",ylab="Frequency",main="Early",breaks=breaks)
hist(treedataEarly[[2]],xlab="Time to apoptosis",ylab="Frequency",main="Early",breaks=breaks)
hist(treedataLate[[1]],xlab="Time to division",ylab="Frequency",main="Late",breaks=breaks)
hist(treedataLate[[2]],xlab="Time to apoptosis",ylab="Frequency",main="Late",breaks=breaks)
dev.off()

## Generate test sets from data
## generateTestsets() splits original dataset in two equal sizes, output in [[1]] and [[2]]. Further 2 x bootstrapN bootstrap datasets are generated, output [[3]].
treedataEarlyExtended <- generateTestsets(treedataEarly,pathEarly,bootstrapN,mins)
treedataLateExtended <- generateTestsets(treedataLate,pathLate,bootstrapN,mins)
treedataHSCExtended <- generateTestsets(treedataHSC,pathHSC,bootstrapN,mins)

###############################################################
## Test pairwise datasets if they are significantly different
## resultsprint() returns 5 summary files
## MPPearlyvsHSCL1_LikelihoodsTreeSetsLeaves.pdf is Figure 3 in Stadler et al., 2017.
MLparEarlyEarly<-resultsprint(treedataEarlyExtended[[1]],treedataEarlyExtended[[2]],paste("MPPearlyvsearlyL",ignoreL,sep=""),pathoutput=pathOut,check=1,ignoreL=ignoreL)
MLparLateLate<-resultsprint(treedataLateExtended[[1]],treedataLateExtended[[2]],paste("MPPlatevslateL",ignoreL,sep=""),pathoutput=pathOut,check=1,ignoreL=ignoreL)
MLparHSCHSC<-resultsprint(treedataHSCExtended[[1]],treedataHSCExtended[[2]],paste("MPPHSCvsHSCL",ignoreL,sep=""),pathoutput=pathOut,check=1,ignoreL=ignoreL)
MLparEarlyLate<-resultsprint(treedataEarly,treedataLate,paste("MPPearlyvslateL",ignoreL,sep=""),pathoutput=pathOut,check=1,ignoreL=ignoreL)
MLparEarlyHSC<-resultsprint(treedataEarly,treedataHSC,paste("MPPearlyvsHSCL",ignoreL,sep=""),pathoutput=pathOut,check=1,ignoreL=ignoreL)
MLparLateHSC<-resultsprint(treedataLate,treedataHSC,paste("MPPlatevsHSCL",ignoreL,sep=""),pathoutput=pathOut,check=1,ignoreL=ignoreL)

## Produce part of table 1 in Stadler et al. 2017.
pars<-read.table(paste("MPPearlyvsHSCL",ignoreL,"_TableEstimates.txt",sep=""))[2,]
pars<-rbind(pars,read.table(paste("MPPearlyvslateL",ignoreL,"_TableEstimates.txt",sep="")))
rownames(pars)<-c("HSC","Early","Late")
pars
if (ignoreL==1){pars<-pars[,-4]}
colnames(pars)<-c("pD","pA","pN","mu_D","sigma_D","mu_A","sigma_A")
print(xtable(pars),file=paste("ParEstL",ignoreL,".tex",sep=""))

###############################################################
## Bootstrap results
## Variable bootstrapresultsD1D2 means:
## in entry 1: 2 (log lik (hat(theta)1|D1) - log lik (hat(theta)2|D1))
## in entry 2: 2 (log lik (hat(theta)2|D2) - log lik (hat(theta)1|D2))

bootstrapresultsEarlyEarly<-distLogLikRatio(treedataEarlyExtended[[3]][1:bootstrapN],treedataEarlyExtended[[3]][(bootstrapN+1):(2*bootstrapN)],ignoreL=ignoreL)
bootstrapresultsHSCHSC<-distLogLikRatio(treedataHSCExtended[[3]][1:bootstrapN],treedataHSCExtended[[3]][(bootstrapN+1):(2*bootstrapN)],ignoreL=ignoreL)
bootstrapresultsLateLate<-distLogLikRatio(treedataLateExtended[[3]][1:bootstrapN],treedataLateExtended[[3]][(bootstrapN+1):(2*bootstrapN)],ignoreL=ignoreL)
bootstrapresultsHSCEarly<-distLogLikRatio(treedataHSCExtended[[3]][1:bootstrapN],treedataEarlyExtended[[3]][1:bootstrapN],ignoreL=ignoreL)
# bootstrapresultsEarlyHSC<-distLogLikRatio(treedataEarlyExtended[[3]][1:bootstrapN],treedataHSCExtended[[3]][1:bootstrapN],ignoreL=ignoreL) same as bootstrapresultsHSCEarly with rows swapped; as expected.
bootstrapresultsEarlyLate<-distLogLikRatio(treedataEarlyExtended[[3]][1:bootstrapN],treedataLateExtended[[3]][1:bootstrapN],ignoreL=ignoreL)

###############################################################
## Perform simulations based on estimated parameters and perform analysis as on original data
n<-250 # number of simulated trees per dataset
upperGen<-3 # number of generations in tree

for (ngen in 3:upperGen){
	parEarly<-MLparEarlyLate[[1]] 
	parLate<-MLparEarlyLate[[2]] 
	parHSC<-MLparEarlyHSC[[2]] 
	treedataSimEarly<-vector()
	treedataSimLate<-vector()
	treedataSimHSC<-vector()
	for (i in 1:(2*bootstrapN)){
		treedataSimEarly<-c(treedataSimEarly,list(simTrees(n,ngen,parEarly)))
		treedataSimLate<-c(treedataSimLate,list(simTrees(n,ngen,parLate)))
		treedataSimHSC<-c(treedataSimHSC,list(simTrees(n,ngen,parHSC)))
	}	
	MLparSimEarlyLate<-resultsprint(treedataSimEarly[[1]],treedataSimLate[[1]],paste("SimMPPearlyvsHSCN",n,"N",ngen,sep=""),check=1,printFile=0,ignoreL=ignoreL)
	MLparSimEarlyHSC<-resultsprint(treedataSimEarly[[1]],treedataSimHSC[[1]],paste("SimMPPearlyvsHSCN",n,"N",ngen,sep=""),check=1,printFile=0,ignoreL=ignoreL)
	MLparSimEarlyEarly<-resultsprint(treedataSimEarly[[1]],treedataSimEarly[[2]],paste("SimMPPearlyvsearlyN",n,"N",ngen,sep=""),check=1,printFile=0,ignoreL=ignoreL)	
	bootstrapresultsSimEarlyEarly<-distLogLikRatio(treedataSimEarly[1:bootstrapN], treedataSimEarly[(bootstrapN+1):(2*bootstrapN)],ignoreL=ignoreL)
	bootstrapresultsSimLateLate<-distLogLikRatio(treedataSimLate[1:bootstrapN], treedataSimLate[(bootstrapN+1):(2*bootstrapN)],ignoreL=ignoreL)
	bootstrapresultsSimHSCHSC<-distLogLikRatio(treedataSimHSC[1:bootstrapN],treedataSimHSC[(bootstrapN+1):(2*bootstrapN)],ignoreL=ignoreL)
	bootstrapresultsSimHSCEarly<-distLogLikRatio(treedataSimHSC[1:bootstrapN],treedataSimEarly[1:bootstrapN],ignoreL=ignoreL)
	bootstrapresultsSimEarlyLate<-distLogLikRatio(treedataSimEarly[1:bootstrapN],treedataSimLate[1:bootstrapN],ignoreL=ignoreL)
}

###############################################################
## Produce Figure 2 in Stadler et al., 2017.
setwd(path)
cutoff<-0.99
# Plot histogram
source("TreeStats-PlotHistogram.R")

# Quantify significance from histograms (0 means that model1 always significantly different than null model) 
sign<-vector()
sign<-rbind(sign,c(
length(which(bootstrapresultsHSCEarly[[1]]<sort(bootstrapresultsEarlyEarly[[1]])[round(bootstrapN*cutoff)])),
length(which(bootstrapresultsSimHSCEarly[[1]]<sort(bootstrapresultsSimEarlyEarly[[1]])[round(bootstrapN*cutoff)])),
length(which(bootstrapresultsHSCEarly[[2]]<sort(bootstrapresultsHSCHSC[[1]])[round(bootstrapN*cutoff)])),
length(which(bootstrapresultsSimHSCEarly[[2]]<sort(bootstrapresultsSimHSCHSC[[1]])[round(bootstrapN*cutoff)])),
length(which(bootstrapresultsEarlyLate[[1]]<sort(bootstrapresultsLateLate[[1]])[round(bootstrapN*cutoff)])),
length(which(bootstrapresultsSimEarlyLate[[1]]<sort(bootstrapresultsSimLateLate[[1]])[round(bootstrapN*cutoff)])),
length(which(bootstrapresultsEarlyLate[[2]]<sort(bootstrapresultsEarlyEarly[[1]])[round(bootstrapN*cutoff)])),
length(which(bootstrapresultsSimEarlyLate[[2]]<sort(bootstrapresultsSimEarlyEarly[[1]])[round(bootstrapN*cutoff)])))
)
sign
setwd(pathOut)
write.table(sign,file="powerAnalysis.txt")

###############################################################
## Determine trees in HSC set which may be real HSCs.
ignoreL<-1

# Pick trees in HSC which are very different from early trees
cutoff<-4
signHSCvsParEarly<- individualtreesPar(MLparEarlyLate[[1]],treedataHSC,"MPPIndHSCvsParEarly",ignoreL)[,2]
signHSCvsParHSC<-individualtreesPar(MLparEarlyHSC[[2]],treedataHSC,"MPPIndHSCvsParHSC",ignoreL)[,2]
index<-which(2*(signHSCvsParEarly - signHSCvsParHSC) > cutoff)
#fraction of HSC trees where HSC parameters fit much better than Early parameters (18% = 53 trees)
length(which(2*(signHSCvsParEarly - signHSCvsParHSC) > cutoff))/length(signHSCvsParEarly)

signEarlyvsParEarly<-individualtreesPar(MLparEarlyLate[[1]],treedataEarly,"MPPIndEarlyvsParEarly",ignoreL)[,2]
signEarlyvsParHSC<-individualtreesPar(MLparEarlyHSC[[2]],treedataEarly,"MPPIndEarlyvsParHSC",ignoreL)[,2]
#fraction of Early trees where HSC parameters fit much better than Early parameters (4.7% = 13 trees)
length(which(2*(signEarlyvsParEarly - signEarlyvsParHSC) > cutoff))/length(signEarlyvsParEarly)

# Write candidate HSC trees in a file
setwd(pathHSC)
filenames <- list.files(pattern="*.txt")
HSCcandidates<-filenames[index]
setwd("/Users/tstadler/Documents/Data/Uni/Research/Datasets0613/LineageTrees/plots")
write.table(HSCcandidates,file="HSCcandidates.txt")

# Analyze candidate HSC trees (HSCtrue) vs remaining HSC trees (HSCfalse)
treedataHSCTrue <-readset(c(pathHSC),list(index),minsize=mins,maxsize=4,shift=1)  # 53 HSC trees
indexFalse<-setdiff(1:length(treedataHSC[[5]]),index)
treedataHSCFalse <-readset(c(pathHSC),list(indexFalse),minsize=mins,maxsize=4,shift=1)
MLparHSCFT<-resultsprint(treedataHSCFalse,treedataHSCTrue,"MPPHSCFT",pathoutput=pathOut, check=1, ignoreL= ignoreL)
MLparHSCFEarly<-resultsprint(treedataHSCFalse,treedataEarly,"MPPHSCFEarly",pathoutput=pathOut,check=1, ignoreL= ignoreL)
MLparHSCTEarly<-resultsprint(treedataHSCTrue,treedataEarly,"MPPHSCTEarly",pathoutput=pathOut,check=1, ignoreL= ignoreL)

# Produce Table 1 in Stadler et al., 2017.
pars<-vector()
setwd("/Users/tstadler/Documents/Data/Uni/Research/Datasets0613/LineageTrees/plots")
pars<-read.table(paste("MPPearlyvsHSCL",ignoreL,"_TableEstimates.txt",sep=""))
pars<-rbind(pars,read.table(paste("MPPHSCFT_TableEstimates.txt",sep="")))
pars<-rbind(pars,read.table(paste("MPPearlyvslateL",ignoreL,"_TableEstimates.txt",sep=""))[2,])
rownames(pars)<-c("EarlyMPP","HSC","HSC_False","HSC_True","LateMPP")
pars <- pars[c(4,2,3,1,5),]
if (ignoreL==1){pars<-pars[,-4]}
colnames(pars)<-c("pD","pA","pN","mu_D","sigma_D","mu_A","sigma_A")
setwd("/Users/tstadler/Documents/Data/Uni/Research/Tex/LineageTrees")
setwd(pathOut)
print(xtable(pars),file=paste("ParEstHSCsplitL",ignoreL,".tex",sep=""))

###############################################################
## Simulations based on estimated parameters from HSCtrue and MPPearly and perform analysis as on original data w.r.t. splitting the dataset
n<-250
ngen <- 3
summaryHSC<-vector()
summaryEarly<-vector()

for (i in 1:100){
	parEarly<-MLparHSCTEarly[[2]]
	parHSCtrue<-MLparHSCTEarly[[1]]
	treedataSimEarly<-vector()
	treedataSimHSC<-vector()
	treedataSimEarly<-c(treedataSimEarly,list(simTrees(n,ngen,parEarly)))[[1]]
	treedataSimHSC<-c(treedataSimHSC,list(simTrees(n/2,ngen,parHSC,parEarly)))[[1]]
	MLparEarlyHSCsim<-resultsprint(treedataSimEarly, treedataSimHSC,paste("MPPearlyvsHSCmixSim",ignoreL,sep=""),pathoutput=pathOut,check=1,ignoreL=ignoreL)

	cutoff<-4 
	
	signHSCvsParEarlySim<- individualtreesPar(MLparEarlyHSCsim[[1]],treedataSimHSC,"MPPIndHSCvsParEarlySim",ignoreL)[,2]
	signHSCvsParHSCSim<-individualtreesPar(MLparEarlyHSCsim[[2]],treedataSimHSC,"MPPIndHSCvsParHSCSim",ignoreL)[,2]
	index<-which(2*(signHSCvsParEarlySim - signHSCvsParHSCSim) > cutoff)
	# fraction of HSC trees where HSC parameters fit much better than Early parameters (data: 18% = 53 trees).
	fracTreesHSC<-length(index)/length(signHSCvsParEarlySim)
	# first n/2 trees were HSC trees, ie. should reject. second n/2 trees were Early trees ie. should not reject.
	summaryHSC<-rbind(summaryHSC,c(length(which(index>n/2)),length(which(index>n/2))/length(index),length(index),fracTreesHSC))
	
	signEarlyvsParEarlySim<-individualtreesPar(MLparEarlyHSCsim[[1]],treedataSimEarly,"MPPIndEarlyvsParEarlySim",ignoreL)[,2]
	signEarlyvsParHSCSim<-individualtreesPar(MLparEarlyHSCsim[[2]],treedataSimEarly,"MPPIndEarlyvsParHSCSim",ignoreL)[,2]
	#fraction of Early trees where HSC parameters fit much better than Early parameters (data: 2.2% = 6 trees).
	index<-which(2*(signEarlyvsParEarlySim - signEarlyvsParHSCSim) > cutoff)
	fracTreesEarly<-length(index)/length(signEarlyvsParEarlySim)
	summaryEarly<-rbind(summaryEarly,c(length(index),fracTreesEarly))
}

# Summary for the 100 simulated datasets:
colnames(summaryHSC)<-c("number of trees falsely rejecting Early", "fraction of rejecting trees which falsely reject Early","number of trees rejecting Early", "fraction of trees rejecting Early")
colnames(summaryEarly)<-c("number of trees rejecting Early", "fraction of trees rejecting Early")
write.table(cbind(summaryHSC,summaryEarly),file="SimDatasetPartition.txt")
	
# Get median and 95 % intervals for the number of trees rejecting Early (in Stadler et al, 2017: "Partitioning the simulated datasets"):	
sort(summaryEarly[,1])
median(summaryEarly[,1])
sort(summaryHSC[,1])
median(summaryHSC[,1])
sort(summaryHSC[,3])
median(summaryHSC[,3])
