
1) Specify the path where you downloaded the folder with all R files in TreeStats.R, second line.
2) Execute the R script TreeStats.R.
3) All results will be in Results/