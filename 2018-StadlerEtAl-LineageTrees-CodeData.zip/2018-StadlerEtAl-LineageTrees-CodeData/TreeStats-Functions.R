readset <-function(path,elements=list(),shift=0,mix=FALSE,minsize=0,maxsize=10^10){
	setD<-vector()
	setA<-vector()
	setN<-vector()
	setL<-vector()
	treestraining<-vector()
	
	for (indpath in 1:length(path)) {
		setwd(path[indpath])
		filenames <- list.files(pattern="*.txt")
		ncomp<-length(filenames)
		nsamp<-1:ncomp
		if (length(elements)>0){
			if (length(elements[[indpath]])>1){nsamp<-elements[[indpath]]} else {nsamp <- sample(nsamp,elements[[indpath]])}
		}
		failure<-vector()	
		tree<-vector()
		
		for (i in nsamp) {
			texttree<-suppressWarnings(read.table(filenames[i],header=FALSE)$V1[1])
			if (class(texttree)=="try-error") {print("Problem in reading a file")}
			texttree<-paste(texttree[1],";",sep="")
			tree2<-try(read.tree(text=texttree),silent=TRUE)
			if (class(tree2)=="phylo" ){ 
				if ( length(tree2$tip.label)<= maxsize && length(tree2$tip.label)>= minsize ){     
					tree2$edge.length<-tree2$edge.length/100000
					tree2$root.edge<-tree2$root.edge/100000	
					tree<-c(tree,list(tree2))
					if(length(tree2$tip.label)>8) {print(filenames[i])} 
			}} else {
				failure <- c(failure,i)} 
		}

		# only trees with more than 1 tip are added and analyzed:
		for (i in 1:length(tree)) {			
			treestrainingtemp<-c(5,length(tree[[i]]$tip.label))
				rootnode<-length(tree[[i]]$tip.label)+1
				for (j in 1:(rootnode-1)){
					typenode <- substr(tree[[i]]$tip.label[j],1+shift,1+shift)
					rownode<-which(tree[[i]]$edge[,2]==j)
					lengthnode <- tree[[i]]$edge.length[rownode]
					if (typenode=="D") {setD<-c(setD,lengthnode)
						treestrainingtemp<-rbind(treestrainingtemp,c(1, lengthnode))}
					if (typenode=="A") {setA<-c(setA,lengthnode)
						treestrainingtemp<-rbind(treestrainingtemp,c(2, lengthnode))}
					if (typenode=="N") {setN<-c(setN,lengthnode)
						treestrainingtemp<-rbind(treestrainingtemp,c(3, lengthnode))}
					if (typenode=="L") {setL<-c(setL,lengthnode)
						treestrainingtemp<-rbind(treestrainingtemp,c(4, lengthnode))}
				}
				if (rootnode<max(tree[[i]]$edge)){		# check if internal branches and go through all internal branches BUT root branch
					for (j in (rootnode+1):max(tree[[i]]$edge)){
						rownode<-which(tree[[i]]$edge[,2]==j)
						lengthnode <- tree[[i]]$edge.length[rownode]
						setD<-c(setD,lengthnode)
						treestrainingtemp<-rbind(treestrainingtemp,c(1, lengthnode))
					}
				}
				if (length(tree[[i]]$tip.label)>1){		# add root branch
					setD<-c(setD,tree[[i]]$root.edge)
					treestrainingtemp<-rbind(treestrainingtemp,c(1, tree[[i]]$root.edge))
				} else {print("check tree size")}
			treestraining<-c(treestraining,list(treestrainingtemp))
		}
		
		# trees with 1 tip are added
		if (minsize<=1){
			for (i in failure) {
				texttree<-suppressWarnings(read.table(filenames[i],header=FALSE)$V1[1])
				typenode <- substr(texttree,1+shift,1+shift)
				lengthnode <- substr(texttree,3+shift,20)
				lengthnode <- as.numeric(lengthnode)/100000	
				if (typenode=="D") {setD<-c(setD,lengthnode)
					print("check! 1 tip tree should not have a D node!")
					k<-1}
				if (typenode=="A") {setA<-c(setA,lengthnode)
					kind<-2}
				if (typenode=="N") {setN<-c(setN,lengthnode)
					kind<-3}
				if (typenode=="L") {setL<-c(setL,lengthnode)
					kind<-4}				
				if (i == 1){treestraining<-c(list(rbind(c(5,1),c(kind,lengthnode))),treestraining)}
				if (i > length(treestraining)){treestraining<-c(treestraining,list(rbind(c(5,1),c(kind,lengthnode))))}
				else {treestraining<-c(treestraining[1:(i-1)],list(rbind(c(5,1),c(kind,lengthnode))),treestraining[(i):length(treestraining)])}
		}}
		print(length(nsamp))
	}
	out<-list(setD,setA,setN,setL,treestraining)
	print("number of trees read (should be sum of above values):")
	print(length(treestraining))
	out
}

generateTestsets<-function(treedata,path,bootstrapN,mins){
	tr<-trunc(length(treedata[[5]])/2)*2
	permute<-sample(tr)
	elements1<-permute[1:(tr/2)]
	elements2<-permute[(tr/2+1):tr]
	treedataSmall1 <-readset(c(path),list(elements1),minsize=mins,maxsize=4,shift=1)
	treedataSmall2 <-readset(c(path),list(elements2),minsize=mins,maxsize=4,shift=1)
	# Bootstrap:
	bootstrap <- vector()
	for (i in 1:(2* bootstrapN)){
		bootstrapindices<-sample(length(treedata[[5]]),replace=TRUE)
		bootstrap<-c(bootstrap,list(readset(c(path),list(bootstrapindices),minsize=mins,maxsize=4,shift=1)))
	}
	out<-c(list(treedataSmall1),list(treedataSmall2),list(bootstrap))
	out
}

distLogLikRatio<-function(databootstrap1,databootstrap2,ignoreL){
	abstrain<-vector()
	abstest<-vector()
	for (i in 1:bootstrapN){
		MLparBootstrap<-resultsprint(databootstrap1[[i]],databootstrap2[[i]],"check",check=0,printFile=0,ignoreL=ignoreL)
		# Lambda(databootstrap1,thetadatabootstrap1,thetadatabootstrap2)
		abstrain<-c(abstrain,MLparBootstrap[[3]][2])
		# Lambda(databootstrap2,thetadatabootstrap2,thetadatabootstrap1)
		abstest<-c(abstest,MLparBootstrap[[3]][4])
	}
	out<-c(list(abstrain),list(abstest))
	out
}

# Calculates ML parameters and produces plots
resultsprint <- function(treedata1,treedata2,filename,pathoutput,mix=FALSE,check=0,printFile=1,ignoreL) {
	setD <- treedata1[[1]]	
	setA <- treedata1[[2]]
	setN  <- treedata1[[3]]
	setL  <- treedata1[[4]]
	treestraining <- treedata1[[5]]
	setDtest  <- treedata2[[1]] 
	setAtest  <- treedata2[[2]]
	setNtest  <- treedata2[[3]] 
	setLtest  <- treedata2[[4]]
	treestest <- treedata2[[5]]
	
	#ML parameters for training set
	parTraining<-MLpar(setD,setA,setN,setL,ignoreL=ignoreL)
	#ML Parameters for test set
	parTest<-MLpar(setDtest,setAtest,setNtest,setLtest,ignoreL=ignoreL)
	
	# numerial optimization yields same result as analytic optimization
	if (check == 1){
		print("Estimates from optim, then analytic; for training set, D:")
		print(optim(c(2,2),lifetime,set=setD)$par)
		print(parTraining[5:6])
		print("Estimates from optim, then analytic; for training set, A:")
		print(optim(c(2,2),lifetime,set=setA)$par)
		print(parTraining[7:8])
	}
	
	# likelihoods of test sets with training ML par
	liktestpartrain<-likset(treestest,parTraining,ignoreL=ignoreL)
	liktestpartest<-likset(treestest,parTest,ignoreL=ignoreL)
	liktrainingpartrain<-likset(treestraining,parTraining,ignoreL=ignoreL)
	liktrainingpartest<-likset(treestraining,parTest,ignoreL=ignoreL)
	
	# verifying correctness: individual trees vs sum of all in training set same likelihood:
	if (check == 1){
		likall<- -log(parTraining[1]^(length(setD))) -log(parTraining[2]^(length(setA)))- log(parTraining[3]^(length(setN))) - log(parTraining[4]^(length(setL))) +lifetime(parTraining[5:6],setD) + lifetime(parTraining[7:8],setA)
		print("Likelihood difference of treestraining, and setA...setL. Should be zero:")
		print(sum(liktrainingpartrain[,1])-likall)
	}
	
	# Are ML parameters significantly better from training set ML parameters, for test set? Significant if >0.95
	abstest<-2*sum((liktestpartrain[,1])-(liktestpartest[,1]))
	signtest<-pchisq(abstest,7-ignoreL)
	abstrain<-2* sum((liktrainingpartest[,1])-(liktrainingpartrain[,1]))
	signtrain<-pchisq(abstrain,7-ignoreL)
	signdiffsets<-c(signtrain,abstrain,signtest,abstest)
	
	# generate OUTPUT
	if (printFile == 1){
	setwd(pathoutput)
	MLest<-round(rbind(parTraining,parTest),digits=3)
	colnames(MLest)<-c("pD","pA","pN","pL","mD","sdD","mA","sdA")
	rownames(MLest)<-c("set1","set2")
	write.table(MLest,paste(filename,"_TableEstimates.txt",sep=""))
	write.table(c(signtrain,abstrain,signtest,abstest),paste(filename,"_pvaluescheck.txt",sep=""),row.names=c("sign_trainingset","abs_trainingest","sign_testset","abs_testset"))
	if (check==1) {
		print("Significance for training and test set parameters: are Test ML estimates significantly better than Train ML estimates for the Test trees? are Train ML estimates significantly better than Test ML estimates for the Train trees?")
		print(c(signtrain,abstrain,signtest,abstest))}
	
	# Visualize how different two sets of trees:
	limits<-length(liktestpartrain[,1])/2
	pdf(paste(filename,"_LikelihoodsTreeSetsLeaves.pdf",sep=""),width=4, height=4)
		ylimit<-max(c(liktrainingpartrain[,2],liktestpartrain[,2]))+0.3
		xlimit<-2*max(abs(liktrainingpartrain[,1]-liktrainingpartest[,1]),abs(liktestpartrain[,1]-liktestpartest[,1]))
		plot(c(-xlimit,xlimit),c(ylimit,0.7),col="white",xlab=expression(paste(Lambda,"(T,",hat(theta)[HSC],",",hat(theta)[Early],")")),
		ylab="number of tips",yaxt = "n")
		axis(2, at = 1 * (1:4), labels = 1:4)
		points(2*(liktrainingpartrain[,1]-liktrainingpartest[,1]),liktrainingpartrain[,2]-0.15)
		if (mix==TRUE){
			points(2*(liktestpartrain[1:limits,1]-liktestpartest[1:limits,1]),liktestpartrain[1:limits,2]+0.1,col="blue")
			points(2*(liktestpartrain[(limits+1):(2*limits),1]-liktestpartest[(limits+1):(2*limits),1]),liktestpartrain[(limits+1):(2*limits),2]+0.2,col="red")}
		points(2*(liktestpartrain[,1]-liktestpartest[,1]),liktestpartrain[,2]+0.15,pch=5)
		lines(c(0,0),c(-ylimit,ylimit),lty="dotted")
		lines(c(4,4),c(-ylimit,ylimit),lty="dashed")
		
	dev.off()
	
	pdf(paste(filename,"_LikelihoodsTreeSets.pdf",sep=""))
		plot(sort(liktrainingpartrain[,1]),xlab="Trees",ylab="likelihood (not difference!!)")
		if (mix==TRUE){
			points(2*(1:limits),sort(liktestpartrain[1:limits,1]),col="blue")
			points(2*(1:limits),sort(liktestpartrain[(limits+1):(2*limits),1]),col="red")}
		points(sort(liktestpartrain[,1]),col="green")
	dev.off()
	
	# Can we see significant difference in one tree from rest?
	pvaluestest<-vector()
	for (i in 1:length(liktestpartrain[,1])){
		pvaluestest<-c(pvaluestest,(liktestpartrain[i,1]-liktestpartest[i,1]))
	}
	pvaluestrain<-vector()
	for (i in 1:length(liktrainingpartrain[,1])){
		pvaluestrain<-c(pvaluestrain,(liktrainingpartrain[i,1]-liktrainingpartest[i,1]))
	}
	pdf(paste(filename,"_LikelihoodsIndTreesTest.pdf",sep=""))
		limitx <- max(length(pvaluestrain),length(pvaluestest))
		limity <- max(abs(pvaluestrain),abs(pvaluestest))
		plot(c(0,limitx),c(limity,-limity),ylab="lik difference",xlab="Trees",main="black: set 1. green: set 2",col="white")
		points(pvaluestrain,col="black")
		points(pvaluestest,col="green")
		if (mix==TRUE){
			lines(c(limits+0.5,limits+0.5),c(-10,10),col="red")}
		lines(c(-10,1000),c(0,0),col="blue")
	dev.off()
	}
		
	out<-c(list(parTraining),list(parTest),list(signdiffsets))
	out
}

# Calculates maximum likelihood parameters for tree set resulting in setD,setA,setN,setL
MLpar <- function(setD,setA,setN,setL,ignoreL){
	if (ignoreL==1) {setL<-vector()}
	nlin<-max(length(setD)+length(setA)+length(setN)+length(setL),1) #in case only cell is a L cell!!
	pD <- length(setD)/nlin
	pA <- length(setA)/nlin
	pN <- length(setN)/nlin
	pL <- length(setL)/nlin
	if (pD==0) {
		mD<-10^5
		sdD<-0 
	} else {
		mD <- mean(setD)
		sdD <- sqrt(sum((setD-mD)^2)/length(setD))
	}
	if (pA==0) {
		mA <- 10^5
		sdA <-0
	} else {	
		mA <- mean(setA)
		sdA <- sqrt(sum((setA-mA)^2)/length(setA))
	}
	parD<-c(mD,sdD)
	parA<-c(mA,sdA)
	out<-c(pD,pA,pN,pL,mD,sdD,mA,sdA)
	out
}

individualtrees<- function(MLpar,treedatalist,limit=0,ignoreL){
	res<-vector()
	for (index in 1:length(treedatalist)){
		treedata<-treedatalist[[index]]
		out1<-likset(treedata[[5]], MLpar[[1]],ignoreL=ignoreL)
		out2<-likset(treedata[[5]], MLpar[[2]],ignoreL=ignoreL)
		out<-cbind(out1[,1]-out2[,1])
		upper<-length((which(out> limit)))/length(out)
		lower <- length((which(out< -limit)))/length(out)
		middle <- 1-upper-lower
		temp<-c(upper,middle,lower,length(out))
		treeset<-temp
		res<-rbind(res,c(treeset,limit))
		if (index==2){
			expect<-vector()
			for (j in 1:3){
				expect<-c(expect,((res[1,j]*res[1,4])+(res[2,j]*res[2,4]))/(res[1,4]+res[2,4]))
			}
			expect<-c(expect,res[1,4]+res[2,4])
			res<-rbind(res,c(expect,limit))
		}
	}	
	colnames(res) <- c("par2preferred","none", "par1preferred","#trees","limit")
	rownames(res) <- c("set1        ","set2        ","setmixexpect","setHSC      ")[1:(length(treedatalist)+1)]
	res<-round(res,3)
	res
}

# Calculates likelihood for each tree in treeset given parameters par
likset <- function(treeset,par,minimumval=10^(-5),ignoreL){
	treestraining<-treeset
	for (i in 1:8) {
		if (par[i]==0){par[i]<-minimumval}	
	}
	pD<-par[1]
	pA<-par[2]
	pN<-par[3]
	pL<-par[4]
	parD<-par[5:6]
	parA<-par[7:8]
	liktraining<-vector()
	for (i in 1:length(treestraining)){	
		temp<-treestraining[[i]]
		linD<-which(temp[,1]==1)
		linA<-which(temp[,1]==2)
		linN<-which(temp[,1]==3)
		linL<-which(temp[,1]==4)
		if (ignoreL == 1) {pL<-1 #makes log(pL)=0 !
			}
		liktree<-  -length(linD)*log(pD) -length(linA)*log(pA)- length(linN)*log(pN) - length(linL)*log(pL)
		if (length(linD) >0){
			liktree<- liktree+lifetime(parD,temp[linD,2])}  # lifetime returns neg log lik
		if (length(linA) >0){
			liktree<- liktree+lifetime(parA,temp[linA,2])}  # lifetime returns neg log lik
		liktraining<-rbind(liktraining,c(liktree,temp[1,2]))		
	}
	liktraining
}

# required in likset
lifetime<-function(par,set){
	m<-par[1]
	sd<-par[2]
	out<-0
	for (i in 1:length(set)){
		out<-out - log(dnorm(set[i],m,sd))
	}
	out
}

# Investigates which parameter set is supported for each tree set
individualtreesPar<- function(MLpar,treedata,filename,ignoreL){
	MLparind<-maxlikset(treedata,ignoreL=ignoreL)
	out<-vector()
	for (index in 1:length(treedata[[5]])) {
		out1<-likset(treedata[[5]][index], MLparind[index,],ignoreL=ignoreL)
		out2<-likset(treedata[[5]][index], MLpar,ignoreL=ignoreL)  
		out3<-pchisq(2*(out2[1]-out1[1]),7-ignoreL)
		out<-rbind(out,c(out1[1],out2[1],out3,out2[2]))
	}
	pdf(paste(filename,"_MLpar.pdf",sep=""))
	hist(-out[,1]+out[,2],xlab="lik difference",main=" ")
	dev.off()
	print(length(which(out[,3]<0.99))/length(out[,3]))
	out
}

# Calculate ML parameters for a treeset
# 1 tip: -log lik = 0 for N, -log lik = -Inf for A, thus minimumval = 10-(5) for something bigger
maxlikset <- function(treeset,ignoreL){
	treestraining<-treeset[[5]]
	ML<-vector()
	for (i in 1:length(treestraining)){	
		temp<-treestraining[[i]]
		linD<-which(temp[,1]==1)
		linA<-which(temp[,1]==2)
		linN<-which(temp[,1]==3)
		linL<-which(temp[,1]==4)
		MLtemp<-MLpar(temp[linD,2],temp[linA,2],temp[linN,2],temp[linL,2],ignoreL=ignoreL)
		ML<-rbind(ML,MLtemp)
	}	
ML
}

# Simulations
# par: "pD","pA","pN","pL","mD","sdD","mA","sdA"
simTrees <- function(n,ngen,par,par2=0){
	out<-c(list(vector()),list(vector()),list(vector()),list(vector()),list(vector()))
	probs<-cumsum(par[1:4])
	for (nindex in 1:n){
	lineages<-1
	out5temp<-vector()
	tips<-0
	for (index in 1:ngen){
		tipstodupl<-0
		lineagesnext<-lineages
		if (lineages > 0) {for (k in 1:lineages){
			tips <- tips +1
			event<-runif(1)
			eventindex<-min(which(probs>event))
			time <- -1
			lineagesnext <-lineagesnext-1
			if (eventindex == 1){
				tips <- tips - 1
				tipstodupl<-tipstodupl+1
				while (time<0){
				time <- rnorm(1,par[5],par[6])}
				lineagesnext <-lineagesnext +2}
			if (eventindex == 2){
				while (time<0){
					time <- rnorm(1,par[7],par[8])}}
			out[[eventindex]]<-c(out[[eventindex]],time)
			out5temp<-rbind(out5temp,c(eventindex,time))
		}
		lineages<-lineagesnext
	}}
	tips<-tips+tipstodupl
	out5temp<-rbind(c(5,tips),out5temp)
	out[[5]]<-c(out[[5]],list(out5temp))
	}
	# For a mix, do the same again:	
	if (length(par2)>1){
		par<-par2	
		probs<-cumsum(par[1:4])
		for (nindex in 1:n){
		lineages<-1
		out5temp<-vector()
		tips<-0
		for (index in 1:ngen){
			tipstodupl<-0
			lineagesnext<-lineages
			if (lineages > 0) {for (k in 1:lineages){
				tips <- tips +1
				event<-runif(1)
				eventindex<-min(which(probs>event))
				time <- -1
				lineagesnext <-lineagesnext-1
				if (eventindex == 1){
					tips <- tips - 1
					tipstodupl<-tipstodupl+1
					while (time<0){
					time <- rnorm(1,par[5],par[6])}
					lineagesnext <-lineagesnext +2}
				if (eventindex == 2){
					while (time<0){
						time <- rnorm(1,par[7],par[8])}}
				out[[eventindex]]<-c(out[[eventindex]],time)
				out5temp<-rbind(out5temp,c(eventindex,time))
			}
			lineages<-lineagesnext
		}}
		tips<-tips+tipstodupl
		out5temp<-rbind(c(5,tips),out5temp)
		out[[5]]<-c(out[[5]],list(out5temp))
	}}
	out
}